// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         // return "Hello";
//         // return 1000;
//         // return true;
//         // return Symbol("Hello");
//         // return undefined;        // Error: Nothing was returned from render
//         // return null;                // I want to render nothing (Blank UI)
//         // return { id: 1 };           //  Error: Objects are not valid as a React child 
//         // return [];
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------------------

// import React from 'react';

// class HelloComponent extends React.Component {
//     render() {
//         return <h1 className="abc">Hello World!</h1>;
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------------------

// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return <h1 className="abc">Hello World!</h1>;
//     }
// }

// export default HelloComponent;

// ---------------------------------------------------------------

// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return (
//             <div>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </div>
//         );
//     }
// }

// export default HelloComponent;

// --------------------------------------------------------------- React Fragments

// import React, { Component } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return (
//             // <React.Fragment>
//             //     <h1 className="abc">Hello World!</h1>
//             //     <h1 className="abc">Hello World Again!</h1>
//             // </React.Fragment>

//             <>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </>
//         );
//     }
// }

// export default HelloComponent;

// --------------------------------------------------------------- React Fragments (It does not render any visible UI)

// import React, { Component, Fragment } from 'react';

// class HelloComponent extends Component {
//     render() {
//         return (
//             <Fragment>
//                 <h1 className="abc">Hello World!</h1>
//                 <h1 className="abc">Hello World Again!</h1>
//             </Fragment>
//         );
//     }
// }

// export default HelloComponent;

// -------------------------------------------------------------- Function Syntax

// import React from 'react';

// function HelloComponent() {
//     return (
//         <>
//             <h1 className="abc">Hello World! - Using Function Declaration Syntax</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </>
//     );
// }

// const HelloComponent = function () {
//     return (
//         <>
//             <h1 className="abc">Hello World! - Using Function Expression Syntax</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </>
//     );
// }

// const HelloComponent = () => {
//     return (
//         <>
//             <h1 className="abc">Hello World! - Using Arrow Syntax</h1>
//             <h1 className="abc">Hello World Again!</h1>
//         </>
//     );
// }

// const HelloComponent = () => (
//     <>
//         <h1 className="abc">Hello World! - Using Single Line Arrow Syntax</h1>
//         <h1 className="abc">Hello World Again!</h1>
//     </>
// );

// export default HelloComponent;

// Class Syntax - Stateful Components / Container Components
// Function Syntax - Stateless Component / Presentational Components

// --------------------------------------------------------------- Using Bootstrap CSS Class

import React, { Component } from 'react';

class HelloComponent extends Component {
    render() {
        return (
            <h1 className="text-info">Hello World!</h1>
        );
    }
}

export default HelloComponent;