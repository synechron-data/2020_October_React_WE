import React, { Component } from 'react';

import TextInput from '../common/TextInput';
import DataTable from '../common/DataTable';

const FormComponent = (props) => {
    return (
        <div className="row">
            <div className="col-sm-6 offset-sm-3">
                <form className="form-horizontal" autoComplete="off" onSubmit={e => {
                    e.preventDefault();
                    props.onSave(e);
                }}>
                    <fieldset>
                        <legend className="text-center text-secondary text-uppercase font-weight-bold">Add Employee Information</legend>
                        <hr className="mt-0" />
                        <TextInput label={"Id"} name={"id"} onChange={props.updateState}
                            value={props.employee.id} readOnly={props.readOnly} type={"number"} />
                        <TextInput label={"Name"} name={"name"} onChange={props.updateState} value={props.employee.name} />
                        <TextInput label={"Designation"} name={"designation"} onChange={props.updateState} value={props.employee.designation} />
                        <TextInput label={"Salary"} name={"salary"} onChange={props.updateState} value={props.employee.salary} />

                        <div className="row mt-3">
                            <div className="col">
                                <button type="submit" className="btn btn-success btn-block">Save</button>
                            </div>
                            <div className="col">
                                <button type="reset" className="btn btn-primary btn-block" onClick={props.reset}>Reset</button>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    );
}

class CRUD_Assignment extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: [],
            employee: { id: 1, name: "", designation: "", salary: "" },
            edit: false
        };
        this.updateState = this.updateState.bind(this);
        this.saveEmployee = this.saveEmployee.bind(this);
        this.removeEmployee = this.removeEmployee.bind(this);
        this.selectEmployee = this.selectEmployee.bind(this);
    }

    updateState(e) {
        const field = e.target.id;
        var newEmployee = { ...this.state.employee };
        if ((field === "id") && e.target.value)
            newEmployee[field] = parseInt(e.target.value);
        else
            newEmployee[field] = e.target.value;
        this.setState({ employee: newEmployee });
    }

    saveEmployee(employee) {
        if (this.state.edit) {
            var employees = [...this.state.employees];
            var itemIndex = employees.findIndex(e => e.id === parseInt(this.state.employee.id));
            employees.splice(itemIndex, 1, { ...this.state.employee });
            this.setState({
                employees: [...employees],
                employee: { id: this.getNextId(this.state.employees), name: "", designation: "", salary: "" },
                edit: false
            });
        } else {
            this.setState({
                employees: [...this.state.employees, { ...this.state.employee }]
            }, () => {
                this.setState({ employee: { id: this.getNextId(this.state.employees), name: "", designation: "", salary: "" } });
            });
        }
    }

    getNextId(employees) {
        return employees.length ? employees[employees.length - 1].id + 1 : 1;
    }

    removeEmployee(id, e) {
        this.setState({
            employees: [...this.state.employees.filter((item => {
                return item.id !== id;
            }))]
        }, () => {
            this.setState({ employee: { id: this.getNextId(this.state.employees), name: "", designation: "", salary: "" } });
        });
    }

    selectEmployee(item) {
        this.setState({ employee: { ...item }, edit: true });
    }

    render() {
        return (
            <div>
                <FormComponent employee={this.state.employee} onSave={this.saveEmployee} updateState={this.updateState} />
                <DataTable items={this.state.employees} onDelete={this.removeEmployee} onSelect={this.selectEmployee}>
                    <h5 className="text-primary text-uppercase font-weight-bold">Employees Table</h5>
                </DataTable>
            </div>
        );
    }
}

export default CRUD_Assignment;