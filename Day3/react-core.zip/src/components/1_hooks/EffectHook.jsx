import React, { useState, useEffect } from 'react';

const EffectHook = () => {
    const [person, setPerson] = useState({ fname: "Manish", lname: "Sharma" });

    // Without Second Parameter, it behaves like ComponentDidUpdate()
    // With Second Parameter, it behaves like ComponentDidMount()

    useEffect(() => {
        console.log("useEffect is called...");
        setTimeout(()=>{
            setPerson({ fname: "Abhijeet", lname: "Gole" })
        }, 5000);
    }, []);

    return (
        <div>
            <h3>Firstname: {person.fname}</h3>
            <h3>Lastname: {person.lname}</h3>
        </div>
    );
};

export default EffectHook;