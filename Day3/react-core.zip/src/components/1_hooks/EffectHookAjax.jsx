import React, { useState, useEffect } from 'react';
import postApiClient from '../../services/postApiClient';
import DataTable from '../common/DataTable';
import LoaderAnimation from '../common/LoaderAnimation';

const EffectHookAjax = () => {
    const [posts, setPosts] = useState([]);
    const [error, setError] = useState('');
    const [load, setLoad] = useState(false);

    // ComponentDidMount
    useEffect(() => {
        postApiClient.getAllPosts().then(data => {
            setPosts(data);
            setLoad(true);
        }).catch(emsg => {
            setError(emsg);
            setLoad(true);
        });
    }, []);

    if (load) {
        return (
            <div>
                {
                    error ?
                        <h2 className="text-danger">{error}</h2>
                        :
                        <DataTable items={posts}>
                            <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
                        </DataTable>
                }
            </div>
        );
    } else {
        return (
            <div className="pt-5">
                <LoaderAnimation />
            </div>
        );
    }
};

export default EffectHookAjax;