/* eslint-disable */

import React, { Component } from 'react';
import EffectHook from '../1_hooks/EffectHook';
import EffectHookAjax from '../1_hooks/EffectHookAjax';
import StateHook from '../1_hooks/StateHook';
import CRUD_Assignment from '../assignment/CRUD_Assignment';
import ErrorHandler from '../common/ErrorHandler';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <CRUD_Assignment /> */}
                    {/* <StateHook /> */}
                    {/* <EffectHook /> */}
                    <EffectHookAjax />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;