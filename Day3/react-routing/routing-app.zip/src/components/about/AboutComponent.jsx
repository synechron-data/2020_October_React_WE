import React from 'react';

const AboutComponent = () => {
    return (
        <div>
            <div>
                <h1 className="text-info">About Component</h1>
                <h4 className="text-warning">This is a Simple, React Routing Application</h4>
            </div>
        </div>
    );
};

export default AboutComponent;