import React, { Component } from 'react';

import DataTable from '../common/DataTable';
import assignmentAPIClient from '../../services/assignment.service';

class AssignmentComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { products: [], message: "Loading Data, please wait..." };
    }

    render() {
        return (
            <div>
                <h1 className="text-info">Assignment Component</h1>

                <br/>

                <a className="btn btn-primary" href="assign/product">Add Product</a>

                <h3 className="text-danger">{this.state.message}</h3>

                <DataTable items={this.state.products}>
                    <h4 className="text-primary text-uppercase font-weight-bold">Products Table</h4>
                </DataTable>
            </div>
        );
    }

    componentDidMount() {
        assignmentAPIClient.getAllProducts().then((data) => {
            this.setState({ products: [...data], message: "" });
        }).catch((eMsg) => {
            this.setState({ message: eMsg });
        });
    }
}

export default AssignmentComponent;