import React, { Component } from 'react';
import postApiClient from '../../services/postApiClient';
import DataTable from '../common/DataTable';

// const ListItem = ({ item }) => {
//     return (
//         <li className="list-group-item">
//             <h3>Id: {item.id}</h3>
//             <h4>{item.title}</h4>
//             <p>{item.body}</p>
//         </li>
//     );
// }

class AjaxComponent extends Component {
    constructor(props) {
        super(props);
        this.state = { posts: [], message: "Loading Data, please wait...." };
    }

    render() {
        // var listItems = this.state.posts.map((item, index) => {
        //     return <ListItem key={index} item={item} />;
        // });

        return (
            <React.Fragment>
                <div className="row">
                    <h4 className="text-warning text-uppercase font-weight-bold">{this.state.message}</h4>
                </div>

                {/* <ul className="list-group">
                    {listItems}
                </ul> */}

                {/* Please display a table instead of ul and li */}
                <DataTable items={this.state.posts}>
                    <h4 className="text-primary text-uppercase font-weight-bold">Posts Table</h4>
                </DataTable>
            </React.Fragment>
        );
    }

    componentDidMount() {
        postApiClient.getAllPosts().then(data => {
            this.setState({ posts: [...data], message: "" });
        }).catch(eMsg => {
            this.setState({ posts: [], message: eMsg });
        });
    }
}

export default AjaxComponent;