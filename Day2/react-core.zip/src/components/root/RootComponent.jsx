/* eslint-disable */

import React, { Component } from 'react';
import ClassVsFunctionalComponents from '../1_class-vs-func/ClassVsFunctionalComponents';
import EventComponent from '../2_synthetic-event/EventComponent';
import CounterAssignment from '../assignment/CounterAssignment';
import ControlledVsUncontrolledComponent from '../3_controlled-vs-uncontrolled/ControlledVsUncontrolledComponent';
import CalculatorAssignment from '../assignment/CalculatorAssignment';
import PropTypesDemo from '../4_prop-types/PropTypesDemo';
import ErrorHandler from '../common/ErrorHandler';
import ParentComponent from '../5_lifecycle-demo/DemoComponent';
import AjaxComponent from '../6_ajax/AjaxComponent';
import ContextAPIDemo from '../7_context-api/ContextAPIDemo';

class RootComponent extends Component {
    render() {
        return (
            <div className="container">
                <ErrorHandler>
                    {/* <ClassVsFunctionalComponents /> */}
                    {/* <EventComponent /> */}
                    {/* <CounterAssignment /> */}
                    {/* <ControlledVsUncontrolledComponent /> */}
                    {/* <CalculatorAssignment /> */}
                    {/* <PropTypesDemo /> */}
                    {/* <ParentComponent /> */}
                    {/* <AjaxComponent /> */}
                    <ContextAPIDemo />
                </ErrorHandler>
            </div>
        );
    }
}

export default RootComponent;