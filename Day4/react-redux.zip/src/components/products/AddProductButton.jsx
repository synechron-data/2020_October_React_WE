// import React from 'react';
// import { withRouter } from 'react-router-dom';

// const AddProductButton = withRouter(({ history }) => {
//     // console.log(props);
//     return (
//         <button className="btn btn-primary" onClick={(e) => {
//             history.push('/product');
//         }}>
//             Add Product
//         </button>
//     );
// })

// export default AddProductButton;

// ---------------------------------------------------------------------
// import React from 'react';
// import { withRouter } from 'react-router-dom';

// const AddProductButton = ({ history }) => {
//     // console.log(props);
//     return (
//         <button className="btn btn-primary" onClick={(e) => {
//             history.push('/product');
//         }}>
//             Add Product
//         </button>
//     );
// };

// export default withRouter(AddProductButton);

// ---------------------------------------------------------------------

import React from 'react';
import { withRouter } from 'react-router-dom';

const AddProductButton = ({ history }) => (
    <button className="btn btn-primary" onClick={(e) => {
        history.push('/product');
    }}>
        Add Product
    </button>
);

export default withRouter(AddProductButton);