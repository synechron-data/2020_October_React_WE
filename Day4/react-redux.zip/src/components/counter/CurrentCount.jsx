import React from 'react';

const CurrentCount = (props) => {
    return (
        <div className="row">
            <h1 className="text-info">Current Count: {props.count}</h1>
        </div>
    );
};

export default CurrentCount;